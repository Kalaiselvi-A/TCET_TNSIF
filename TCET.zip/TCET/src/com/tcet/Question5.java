package com.tcet;

import java.util.Arrays;
import java.util.Scanner;

public class Question5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
        System.out.println("Enter the number of crates:");
        int n = sc.nextInt();
        
        int[] crates = new int[n];
        
        System.out.println("Enter the values for the crates (values, 0 for empty):");
        for (int i = 0; i < n;crates[i] = sc.nextInt(), i++);
        
        int[] result = moveZerosToEnd(crates);
        
        System.out.println("Crates after moving zeros to the end: " + Arrays.toString(result));
        
        sc.close();
    }

    public static int[] moveZerosToEnd(int[] crates) {

    	int[] nonZeroCrates = Arrays.stream(crates)
                                    .filter(crate -> crate != 0)
                                    .toArray();
        
        int[] res = new int[crates.length];
        
        System.arraycopy(nonZeroCrates, 0, res, 0, nonZeroCrates.length);
        
        return res;
	}

}
