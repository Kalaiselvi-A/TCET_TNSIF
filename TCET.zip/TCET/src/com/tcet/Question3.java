package com.tcet;

import java.util.HashMap;
import java.util.Map;

public class Question3 {

	public static void main(String[] args) {
        String input = "This is a test string. This string is for testing.";
        String[] words = input.split("\\s+");
        Map<String, Integer> wordCountMap = new HashMap<>();
        
        for(String str : words) {
        	str = str.toLowerCase();
        	
        	if (wordCountMap.containsKey(str)) {
                wordCountMap.put(str, wordCountMap.get(str) + 1);
            } else {
                wordCountMap.put(str, 1);
            }
        }
        
        for (Map.Entry<String, Integer> entry : wordCountMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

	}

}
