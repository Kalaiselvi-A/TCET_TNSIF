package com.tcet;

import java.util.Scanner;

@FunctionalInterface
interface Sayable {
    String say(String msg);
}

public class Question1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String user = sc.nextLine();
		
		Sayable sayable = (message) -> "Hello, " + message;
        
        String greet = sayable.say(user);
        System.out.println(greet);
        
        sc.close();
	}

}
