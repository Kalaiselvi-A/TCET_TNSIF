package com.tcet;

class NumPrint implements Runnable {
	
    @Override
    public void run() {
        
        for (int i = 1; i <= 5; i++) {
            System.out.println(i);
            try {
                Thread.sleep(500); 
            }
            catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}


public class Question2 {

	public static void main(String[] args) {
		NumPrint print = new NumPrint();
		
		Thread thr = new Thread(print);
		
		thr.start();

	}

}
